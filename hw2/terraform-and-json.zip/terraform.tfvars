# Important AWS credentials
# DO NOT COMMIT THEM TO PUBLIC SPACE (e.g. GIT)
ssh_cidr = "108.7.160.224/32"
ssh_key_name = "hw1bkey-pair"